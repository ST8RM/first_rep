package com.example.demo.models;

import org.springframework.data.repository.CrudRepository;

public interface host_repos extends CrudRepository<host_repos,Long> {
}
