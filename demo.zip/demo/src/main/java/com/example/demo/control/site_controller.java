package com.example.demo.control;

import com.example.demo.models.host_repos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class site_controller {
    @Autowired
    private host_repos host_reposit;

    @GetMapping ("/about")
    public String MainShop(Model model) {
        Iterable<host_repos> hosts = host_reposit.findAll();
        model.addAttribute("posts",hosts);
return "shop_Main";
    }
}
